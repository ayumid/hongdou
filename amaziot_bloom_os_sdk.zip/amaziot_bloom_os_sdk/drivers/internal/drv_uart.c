//------------------------------------------------------------------------------
// Copyright , 2017-2021 奇迹物联（北京）科技有限公司
// Filename    : drv_uart.c
// Auther      : win
// Version     :
// Date : 2021-11-23
// Description :
//          
//          
// History     :
//     
//    1. Time         : 2021-11-23
//       Modificator  : win
//       Modification : Created
//    2.
// Others :
//------------------------------------------------------------------------------

// Includes ---------------------------------------------------------------------

#include "drv_uart.h"

// Private defines / typedefs ---------------------------------------------------

// Private variables ------------------------------------------------------------

// Public variables -------------------------------------------------------------

// Private functions prototypes -------------------------------------------------

// Functions --------------------------------------------------------------------
/**
  * Function    : drv_uartAT_init
  * Description : AT口初始化
  * Input       : AT口接收回调函数
  *               
  * Output      : 
  * Return      : 
  * Auther      : win
  * Others      : 
  **/
void drv_uartAT_init(uartRecvCallback recv_cb)
{
	UART_OPEN(recv_cb);
}
/**
  * Function    : drv_uartAT_send_data
  * Description : AT口发送数据
  * Input       : bufPtr 数据
  *               length 长度
  * Output      : 
  * Return      : 
  * Auther      : win
  * Others      : 
  **/
void drv_uartAT_send_data(unsigned char *bufPtr, unsigned long length)
{
	UART_SEND_DATA(bufPtr,length);
}
/**
  * Function    : drv_uartAT_set_baud
  * Description : 设置AT口波特率
  * Input       : baudRate 波特率
  *               
  * Output      : 
  * Return      : 
  * Auther      : win
  * Others      : 
  **/
void drv_uartAT_set_baud(UART_BaudRates baudRate)
{
	UART_SET_BAUD(baudRate);
}
/**
  * Function    : drv_uartAT_get_baud
  * Description : 获取AT口波特率
  * Input       : 
  *               
  * Output      : 
  * Return      : AT口波特率
  * Auther      : win
  * Others      : 
  **/
UART_BaudRates drv_uartAT_get_baud(void)
{
	UART_GET_BAUD();
}



/**
  * Function    : drv_uart3_init
  * Description : UART3初始化
  * Input       : UART3接收回调函数
  *               
  * Output      : 
  * Return      : 
  * Auther      : win
  * Others      : 
  **/
void drv_uart3_init(uartRecvCallback recv_cb)
{
	UART3_OPEN(recv_cb);
}
/**
  * Function    : drv_uart3_send_data
  * Description : UART3发送数据
  * Input       : bufPtr 数据
  *               length 长度
  *               
  * Output      : 
  * Return      : 
  * Auther      : win
  * Others      : 
  **/
void drv_uart3_send_data(unsigned char *bufPtr, unsigned long length)
{
	UART3_SEND_DATA(bufPtr,length);
}
/**
  * Function    : drv_uart3_set_baud
  * Description : 设置UART3波特率
  * Input       : baudRate 波特率
  *               
  * Output      : 
  * Return      : 
  * Auther      : win
  * Others      : 
  **/
void drv_uart3_set_baud(UART_BaudRates baudRate)
{
	UART3_SET_BAUD(baudRate);
}
/**
  * Function    : drv_uart3_get_baud
  * Description : 获取UART3波特率
  * Input       : 
  *               
  * Output      : 
  * Return      : UART3波特率
  * Auther      : win
  * Others      : 
  **/
UART_BaudRates drv_uart3_get_baud(void)
{
	UART3_GET_BAUD();
}

/**
  * Function    : drv_uart4_init
  * Description : UART4初始化
  * Input       : UART4接收回调函数
  *               
  * Output      : 
  * Return      : 
  * Auther      : win
  * Others      : 
  **/
void drv_uart4_init(uartRecvCallback recv_cb)
{
	UART4_OPEN(recv_cb);
}
/**
  * Function    : drv_uart4_send_data
  * Description : UART4发送数据
  * Input       : bufPtr 数据
  *               length 长度
  *               
  * Output      : 
  * Return      : 
  * Auther      : win
  * Others      : 
  **/
void drv_uart4_send_data(unsigned char *bufPtr, unsigned long length)
{
	UART4_SEND_DATA(bufPtr,length);
}
/**
  * Function    : drv_uart4_set_baud
  * Description : 设置UART4波特率
  * Input       : baudRate 波特率
  *               
  * Output      : 
  * Return      : 
  * Auther      : win
  * Others      : 
  **/
void drv_uart4_set_baud(UART_BaudRates baudRate)
{
	UART4_SET_BAUD(baudRate);
}
/**
  * Function    : drv_uart4_get_baud
  * Description : 获取UART4波特率
  * Input       : 
  *               
  * Output      : 
  * Return      : UART4波特率
  * Auther      : win
  * Others      : 
  **/
UART_BaudRates drv_uart4_get_baud(void)
{
	UART4_GET_BAUD();
}



// End of file : drv_uart.h 2021-11-23 18:14:09 by: win 

