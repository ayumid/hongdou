//------------------------------------------------------------------------------
// Copyright , 2017-2021 奇迹物联（北京）科技有限公司
// Filename    : drv_uart.h
// Auther      : win
// Version     :
// Date : 2021-11-23
// Description :
//          
//          
// History     :
//     
//    1. Time         : 2021-11-23
//       Modificator  : win
//       Modification : Created
//    2.
// Others :
//------------------------------------------------------------------------------
// Define to prevent recursive inclusion ----------------------------------------
#ifndef _DRV_UART_H_
#define _DRV_UART_H_

// Includes ---------------------------------------------------------------------
#include "osa.h"
#include "sdk_api.h"
#include "UART.h"

// Public defines / typedef -----------------------------------------------------

// Public functions prototypes --------------------------------------------------
/**
  * Function    : drv_uartAT_init
  * Description : AT口初始化
  * Input       : AT口接收回调函数
  *               
  * Output      : 
  * Return      : 
  * Auther      : win
  * Others      : 
  **/
void drv_uartAT_init(uartRecvCallback recv_cb);
/**
  * Function    : drv_uartAT_send_data
  * Description : AT口发送数据
  * Input       : bufPtr 数据
  *               length 长度
  * Output      : 
  * Return      : 
  * Auther      : win
  * Others      : 
  **/
void drv_uartAT_send_data(unsigned char *bufPtr, unsigned long length);
/**
  * Function    : drv_uartAT_set_baud
  * Description : 设置AT口波特率
  * Input       : baudRate 波特率
  *               
  * Output      : 
  * Return      : 
  * Auther      : win
  * Others      : 
  **/
void drv_uartAT_set_baud(UART_BaudRates baudRate);
/**
  * Function    : drv_uartAT_get_baud
  * Description : 获取AT口波特率
  * Input       : 
  *               
  * Output      : 
  * Return      : AT口波特率
  * Auther      : win
  * Others      : 
  **/
UART_BaudRates drv_uartAT_get_baud(void);
/**
  * Function    : drv_uart3_init
  * Description : UART3初始化
  * Input       : UART3接收回调函数
  *               
  * Output      : 
  * Return      : 
  * Auther      : win
  * Others      : 
  **/
void drv_uart3_init(uartRecvCallback recv_cb);
/**
  * Function    : drv_uart3_send_data
  * Description : UART3发送数据
  * Input       : bufPtr 数据
  *               length 长度
  *               
  * Output      : 
  * Return      : 
  * Auther      : win
  * Others      : 
  **/
void drv_uart3_send_data(unsigned char *bufPtr, unsigned long length);

/**
  * Function    : drv_uart3_set_baud
  * Description : 设置UART3波特率
  * Input       : baudRate 波特率
  *               
  * Output      : 
  * Return      : 
  * Auther      : win
  * Others      : 
  **/
void drv_uart3_set_baud(UART_BaudRates baudRate);
/**
  * Function    : drv_uart3_get_baud
  * Description : 获取UART3波特率
  * Input       : 
  *               
  * Output      : 
  * Return      : UART3波特率
  * Auther      : win
  * Others      : 
  **/
UART_BaudRates drv_uart3_get_baud(void);
/**
  * Function    : drv_uart4_init
  * Description : UART4初始化
  * Input       : UART4接收回调函数
  *               
  * Output      : 
  * Return      : 
  * Auther      : win
  * Others      : 
  **/
void drv_uart4_init(uartRecvCallback recv_cb);

/**
  * Function    : drv_uart4_send_data
  * Description : UART4发送数据
  * Input       : bufPtr 数据
  *               length 长度
  *               
  * Output      : 
  * Return      : 
  * Auther      : win
  * Others      : 
  **/
void drv_uart4_send_data(unsigned char *bufPtr, unsigned long length);
/**
  * Function    : drv_uart4_set_baud
  * Description : 设置UART4波特率
  * Input       : baudRate 波特率
  *               
  * Output      : 
  * Return      : 
  * Auther      : win
  * Others      : 
  **/
void drv_uart4_set_baud(UART_BaudRates baudRate);
/**
  * Function    : drv_uart4_get_baud
  * Description : 获取UART4波特率
  * Input       : 
  *               
  * Output      : 
  * Return      : UART4波特率
  * Auther      : win
  * Others      : 
  **/
UART_BaudRates drv_uart4_get_baud(void);

#endif /* ifndef _DRV_UART_H_.2021-11-23 18:14:16 by: win */

