//------------------------------------------------------------------------------
// Copyright , 2017-2021 奇迹物联（北京）科技有限公司
// Filename    : examples_sleep.c
// Auther      : win
// Version     :
// Date : 2021-11-25
// Description :
//          
//          
// History     :
//     
//    1. Time         : 2021-11-25
//       Modificator  : win
//       Modification : Created
//    2.
// Others :
//------------------------------------------------------------------------------

// Includes ---------------------------------------------------------------------

#include "incl_config.h"
#include "utils_common.h"
#include "drv_pwr.h"
#include "lib_net.h"
#include "lib_socket.h"

#ifdef INCL_EXAMPLES_SLEEP
// Private defines / typedefs ---------------------------------------------------
#define _TASK_STACK_SIZE     1280
static UINT32 _task_stack[_TASK_STACK_SIZE/sizeof(UINT32)];
static OSTaskRef _task_ref = NULL;

#define RECV_TASK_STACK_SIZE     1280
static UINT32 recv_task_stack[_TASK_STACK_SIZE/sizeof(UINT32)];
static OSTaskRef recv_task_ref = NULL;

#define SOCKET_MSGQ_MSG_SIZE              (sizeof(socket_msgq_msg))
#define SOCKET_MSGQ_QUEUE_SIZE            (4)

// Private variables ------------------------------------------------------------
typedef struct
{
    int socket_fd;
}socket_msgq_msg;
static OSMsgQRef    socketMsgQ;

UINT16 heartbeat_ack_miss_count = 0;
#define RECV_FD_MAX 64

// Public variables -------------------------------------------------------------

// Private functions prototypes -------------------------------------------------
static void recv_task(void *ptr);
static void _task(void *ptr);

// Device bootup hook before Phase1Inits.
// If you have some work to be init, you may implete it here.
// ex: you may start your task here. or do some initialize here.
extern void Phase1Inits_enter(void);
// Device bootup hook after Phase1Inits.
// If you have some work to be init, you may implete it here.
// ex: you may start your task here. or do some initialize here.
extern void Phase1Inits_exit(void);
// Device bootup hook before Phase2Inits.
// If you have some work to be init, you may implete it here.
// ex: you may start your task here. or do some initialize here.
extern void Phase2Inits_enter(void);
// Device bootup hook after Phase2Inits.
// If you have some work to be init, you may implete it here.
// ex: you may start your task here. or do some initialize here.
extern void Phase2Inits_exit(void);

// Functions --------------------------------------------------------------------
void Phase1Inits_enter(void)
{
}

void Phase1Inits_exit(void)
{
}

void Phase2Inits_enter(void)
{
}


void Phase2Inits_exit(void)
{
	int ret;
    /*creat msgq*/
    ret = OSAMsgQCreate(&socketMsgQ, "socketMsgQ", SOCKET_MSGQ_MSG_SIZE, SOCKET_MSGQ_QUEUE_SIZE, OS_FIFO);
    ASSERT(ret == OS_SUCCESS);

    ret = OSATaskCreate(&_task_ref, _task_stack, _TASK_STACK_SIZE, 150, "test-task", _task, NULL);
    ASSERT(ret == OS_SUCCESS);

    ret = OSATaskCreate(&recv_task_ref, recv_task_stack, RECV_TASK_STACK_SIZE, 150, "recv-task", recv_task, NULL);
    ASSERT(ret == OS_SUCCESS);

}

static void _task(void *ptr)
{
    int ret, sock = -1;
    struct addrinfo hints;
    struct addrinfo *result, *rp;
    char buf[128] = {0};
    int timeout;
    socket_msgq_msg msg;

    ret = lib_net_tcpip_ok(50);
	if(ret != 0){
		 sdk_uart_printf("join net error!\n");
	}
    drv_pwr_enable_sys_sleep();
	
RECONNECT:
    sdk_uart_printf("_task connenct or reconnenct server\n");

    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = 0;
    hints.ai_protocol = 0;
    ret = lib_getaddrinfo("test.51modem.com", "3366", &hints, &result);
    if (ret != 0) {
        sdk_uart_printf("_testsocket: resolve error\n");
        return;
    }

    for (rp = result; rp; rp = rp->ai_next) {
        sock = lib_socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);
        if (sock < 0) {
            sdk_uart_printf("_testsocket: socket error\n");
            continue;
        }

        timeout = 20 * 1000;	// 20s recv timeout
        lib_setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
		
        ret = lib_connect(sock, rp->ai_addr, rp->ai_addrlen);
        if (ret < 0) {
            sdk_uart_printf("_testsocket: connect error\n");
            lib_close(sock);
            continue;
        } else {
            break;
        }
    }

    lib_freeaddrinfo(result);

    if (sock < 0) {
        sdk_uart_printf("_testsocket: connect error\n");
        goto RECONNECT;
    }

    msg.socket_fd = sock;
    OSAMsgQSend(socketMsgQ, SOCKET_MSGQ_MSG_SIZE, (void*)&msg, OSA_NO_SUSPEND);

    while(1){
	    ret = lib_send(sock, "**000**", 7, 0);		// send heartbeat packet
	    if (ret != 7) {
	        sdk_uart_printf("_testsocket: send error\n");
	        lib_close(sock);
	        goto RECONNECT;
	    }
		
	    sleep(60*5);	// not set timer, In sleep state, the timer is unfaithful
	    heartbeat_ack_miss_count++;
	    if (heartbeat_ack_miss_count >= 3){
			
	    	heartbeat_ack_miss_count = 0;
	    	lib_close(sock);
	       goto RECONNECT;
	    }
    }

}

static void recv_task(void *ptr)
{
	int fd = -1;
	socket_msgq_msg msg;

	int fdmax, j, bytes;
	fd_set master, read_fds;
	int errorno=0;
	char buf[128] = {0};
	struct sockaddr_in server;
	socklen_t addrlen = sizeof(server);
	
	fdmax = RECV_FD_MAX;
	
   	while(1)
	{
		OSAMsgQRecv(socketMsgQ, (void *)&msg, SOCKET_MSGQ_MSG_SIZE, OSA_SUSPEND);
		
		fd = msg.socket_fd;

		FD_ZERO(&master);
		FD_ZERO(&read_fds);
		FD_SET(fd, &master);
		while (1) {
			read_fds = master;
			if (select(fdmax, &read_fds, NULL, NULL, NULL) == -1) {
				errorno=lwip_getsockerrno(fd);
				sdk_uart_printf("%s, select error %d", __FUNCTION__, errorno);
				if(errorno==ENETRESET || errorno==ECONNABORTED || errorno==ENOTCONN){
					FD_CLR(fd, &master);
					break;
				}
				sleep(1);
				continue;
			}

			for (j = 0; j < fdmax; j++) {
				if (!FD_ISSET(j, &read_fds)) {
					continue;
				}

				memset(buf, 0, sizeof(buf));

				bytes = lib_recvfrom(fd, buf, sizeof(buf), 0, (struct sockaddr *)&server, &addrlen);	// once, max recv 1460	
				sdk_uart_printf("recvfrom: bytes %d\n", bytes);
				if (bytes <= 0) {
					lib_close(fd);
				}else{
					sdk_uart_printf("recvfrom: bytes %d, %s\n", bytes, buf);

					if (strncmp("**111**", buf, 7) == 0){
						heartbeat_ack_miss_count = 0;
					}else if (strncmp("**222**", buf, 7) == 0){
						drv_pwr_disable_sys_sleep();
					}else{

					}
				}
			}
		}
	}

}



#endif /* ifdef INCL_EXAMPLES_SLEEP.2021-11-25 11:30:31 by: win */

// End of file : examples_sleep.h 2021-11-25 11:30:14 by: win 

