﻿//------------------------------------------------------------------------------
// Copyright , 2017-2021 奇迹物联（北京）科技有限公司
// Filename    : examples_uart.c
// Auther      : win
// Version     :
// Date : 2021-11-25
// Description :
//          
//          
// History     :
//     
//    1. Time         : 2021-11-25
//       Modificator  : win
//       Modification : Created
//    2.
// Others :
//------------------------------------------------------------------------------

// Includes ---------------------------------------------------------------------

#include "incl_config.h"
#include "utils_common.h"
#include "drv_uart.h"


#ifdef INCL_EXAMPLES_UART
// Private defines / typedefs ---------------------------------------------------

// Private variables ------------------------------------------------------------
static OSMsgQRef uartMsgQ;

typedef struct{    
    int len;
    UINT8 *data;
}uartParam;

static void uart_thread(void);

// Public variables -------------------------------------------------------------

// Private functions prototypes -------------------------------------------------
// Device bootup hook before Phase1Inits.
// If you have some work to be init, you may implete it here.
// ex: you may start your task here. or do some initialize here.
extern void Phase1Inits_enter(void);
// Device bootup hook after Phase1Inits.
// If you have some work to be init, you may implete it here.
// ex: you may start your task here. or do some initialize here.
extern void Phase1Inits_exit(void);
// Device bootup hook before Phase2Inits.
// If you have some work to be init, you may implete it here.
// ex: you may start your task here. or do some initialize here.
extern void Phase2Inits_enter(void);
// Device bootup hook after Phase2Inits.
// If you have some work to be init, you may implete it here.
// ex: you may start your task here. or do some initialize here.
extern void Phase2Inits_exit(void);

// Functions --------------------------------------------------------------------
void Phase1Inits_enter(void)
{

}

void Phase1Inits_exit(void)
{
}

void Phase2Inits_enter(void)
{
}

void Phase2Inits_exit(void)
{
    OSA_STATUS status;

    sdk_uart_printf("%s[%d]: starting...\n", __FUNCTION__, __LINE__);
    status = OSAMsgQCreate(&uartMsgQ, "uartMsgQ", sizeof(uartParam), 300, OS_FIFO);
    ASSERT(status == OS_SUCCESS);

    sys_thread_new("uart_thread", uart_thread, NULL, 4096*2, 181);
}

void mainUartRecvCallback(UINT8 * recv_data, UINT32 recv_len)
{	
	uartParam uart_data = {0};
    OSA_STATUS osa_status;
    
    char *tempbuf = (char *)malloc(recv_len+10);
    memset(tempbuf, 0x0, recv_len+10);
    memcpy(tempbuf, (char *)recv_data, recv_len);
	
    sdk_uart_printf("%s[%d]: recv_len:%d, recv_data:%s\n", __FUNCTION__, __LINE__, recv_len, (char *)(recv_data)); 
    uart_data.data = (UINT8 *)tempbuf;
    uart_data.len = recv_len;
	
    osa_status = OSAMsgQSend(uartMsgQ, sizeof(uartParam), (UINT8*)&uart_data, OSA_NO_SUSPEND);
    ASSERT(osa_status == OS_SUCCESS);
}


static void uart_thread(void)
{
    uartParam uart_temp;	
    OSA_STATUS status;
    UART_BaudRates baud;
	
	drv_uartAT_init(mainUartRecvCallback); 
	
    baud = drv_uartAT_get_baud();
	
	sdk_uart_printf("%s: baud %d\n", __FUNCTION__, baud);
	
    while (1) {
        memset(&uart_temp, 0, sizeof(uartParam));
        
        status = OSAMsgQRecv(uartMsgQ, (UINT8 *)&uart_temp, sizeof(uartParam), OSA_SUSPEND);//recv data from uart
        
        if (status == OS_SUCCESS) {
            if (uart_temp.data) {
                sdk_uart_printf("%s[%d]: uart_temp len:%d, data:%s\n", __FUNCTION__, __LINE__, uart_temp.len, (char *)(uart_temp.data));
				
                drv_uartAT_send_data(uart_temp.data,uart_temp.len);
				
				free(uart_temp.data);
            }
        }
    }
}

#endif /* ifdef INCL_EXAMPLES_UART.2021-11-25 12:04:55 by: win */

// End of file : examples_uart.h 2021-11-25 12:04:21 by: win 

