#ifndef __MB_CRC16_H
#define __MB_CRC16_H
typedef unsigned char				uint8_t;
typedef unsigned short				uint16_t;

uint16_t mb_crc16( uint8_t * pFrame, uint16_t len );

#endif

