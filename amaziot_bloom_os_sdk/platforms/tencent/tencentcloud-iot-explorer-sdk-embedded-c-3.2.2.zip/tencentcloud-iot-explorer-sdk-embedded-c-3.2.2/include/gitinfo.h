#ifndef __GIT_INFO_H_
#define __GIT_INFO_H_
#define GIT_COMMIT_ID "d7b2eff2d4488da49167449ed93dff5607de5ba6"
#endif
