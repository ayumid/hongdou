/**
 * @file tuya_config.h
 * @brief IoT specific configuration file
 */

#ifndef TUYA_CONFIG_H_
#define TUYA_CONFIG_H_

#define TUYA_PRODUCT_KEY      "ff1lwoe4t5rkeg5m" // for test
#define TUYA_DEVICE_UUID      "tuyac0828c3dfbc6a170"
#define TUYA_DEVICE_AUTHKEY   "gxQPs3qtR0pNSx12hh0floVG117uUnJL"
#endif