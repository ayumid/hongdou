Name: 基于MQTT的动态注册
MQTT-dynreg Component for Link Kit SDK V4.0.0
