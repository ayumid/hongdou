Name: 动态注册
DYNREG Component for Link SDK V4.0.0

