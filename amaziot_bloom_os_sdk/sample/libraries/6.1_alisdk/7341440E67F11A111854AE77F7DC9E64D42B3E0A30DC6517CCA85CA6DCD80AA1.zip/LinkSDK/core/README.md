Name: 核心模块
Core Component for LinkSDK V4.0.0
