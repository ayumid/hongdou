#ifndef _CORE_STDINC_H_
#define _CORE_STDINC_H_

#if defined(__cplusplus)
extern "C" {
#endif

#include <stdint.h>
#include <string.h>

#if defined(__cplusplus)
}
#endif

#endif

