# MQTT协议数据流接入SDK使用手册

```shell
|-- common
|-- example
|-- onenet
    |-- platforms
    |-- protocols
    |-- security
|-- services
|-- tools
|-- config.h
`-- CMakeLists.txt
```

## 常用配置选项说明

sdk常用选项以宏定义的方式定义再config.h文件中，详情参见config.h

## sdk适配步骤

## wolfssl移植

wolfssl移植步骤参见[官方文档](https://www.wolfssl.com/docs/)